﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Editor
{
    public class ItemContainer
    {

        public int Index { get; set; }
        public byte[] String { get; set; }



    }
}
