﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace String_Editor
{
    public class StringContainer
    {
        public int Index { get; set; }
        public byte[] name { get; set; }
        public byte[] descr { get; set; }
        public byte[] descr2 { get; set; }
    }
}
